object Frmlstdoccom: TFrmlstdoccom
  Left = 220
  Top = 243
  BorderStyle = bsDialog
  Caption = 'Listado de Documentaci'#243'n por Comisi'#243'n'
  ClientHeight = 98
  ClientWidth = 383
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnActivate = FormActivate
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 0
    Top = 0
    Width = 383
    Height = 98
    Align = alClient
    Caption = 'Datos de la comisi'#243'n'
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 24
      Width = 42
      Height = 13
      Caption = 'Comisi'#243'n'
    end
    object Label2: TLabel
      Left = 168
      Top = 24
      Width = 58
      Height = 13
      Caption = 'Cuatrimestre'
    end
    object comision: TEdit
      Left = 104
      Top = 16
      Width = 49
      Height = 21
      MaxLength = 3
      TabOrder = 0
      OnKeyPress = comisionKeyPress
    end
    object cuatrimestre: TEdit
      Left = 240
      Top = 16
      Width = 49
      Height = 21
      MaxLength = 3
      TabOrder = 1
      OnKeyPress = cuatrimestreKeyPress
    end
    object Imprimir: TBitBtn
      Left = 194
      Top = 64
      Width = 75
      Height = 25
      Caption = '&Imprimir'
      TabOrder = 2
      OnClick = ImprimirClick
      Glyph.Data = {
        76010000424D7601000000000000760000002800000020000000100000000100
        04000000000000010000130B0000130B00001000000000000000000000000000
        800000800000008080008000000080008000808000007F7F7F00BFBFBF000000
        FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00300000000000
        00033FFFFFFFFFFFFFFF0888888888888880777777777777777F088888888888
        8880777777777777777F0000000000000000FFFFFFFFFFFFFFFF0F8F8F8F8F8F
        8F80777777777777777F08F8F8F8F8F8F9F0777777777777777F0F8F8F8F8F8F
        8F807777777777777F7F0000000000000000777777777777777F3330FFFFFFFF
        03333337F3FFFF3F7F333330F0000F0F03333337F77773737F333330FFFFFFFF
        03333337F3FF3FFF7F333330F00F000003333337F773777773333330FFFF0FF0
        33333337F3FF7F3733333330F08F0F0333333337F7737F7333333330FFFF0033
        33333337FFFF7733333333300000033333333337777773333333}
      NumGlyphs = 2
    end
  end
  object salir: TBitBtn
    Left = 278
    Top = 64
    Width = 75
    Height = 25
    Caption = '&Salir'
    TabOrder = 1
    OnClick = salirClick
    Glyph.Data = {
      76010000424D7601000000000000760000002800000020000000100000000100
      04000000000000010000120B0000120B00001000000000000000000000000000
      800000800000008080008000000080008000808000007F7F7F00BFBFBF000000
      FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00330000000000
      03333377777777777F333301BBBBBBBB033333773F3333337F3333011BBBBBBB
      0333337F73F333337F33330111BBBBBB0333337F373F33337F333301110BBBBB
      0333337F337F33337F333301110BBBBB0333337F337F33337F333301110BBBBB
      0333337F337F33337F333301110BBBBB0333337F337F33337F333301110BBBBB
      0333337F337F33337F333301110BBBBB0333337F337FF3337F33330111B0BBBB
      0333337F337733337F333301110BBBBB0333337F337F33337F333301110BBBBB
      0333337F3F7F33337F333301E10BBBBB0333337F7F7F33337F333301EE0BBBBB
      0333337F777FFFFF7F3333000000000003333377777777777333}
    NumGlyphs = 2
  end
  object SqlCursada: TQuery
    SQL.Strings = (
      
        'SELECT Alumnos.COD_ALU, Alumnos.APELLIDO, Alumnos.NOM_APE, Alumn' +
        'os.CTT,'
      
        '       Alumnos.FECH_CTT, Alumnos.DNI, Alumnos.CD, Alumnos.CA, Al' +
        'umnos.CR,'
      '       Alumnos.RESIDE'
      'FROM "ALUMNOS.DBF" Alumnos'
      
        'WHERE Alumnos.COD_ALU IN (SELECT COD_ALU FROM "Cursada.DBF" Curs' +
        'ada'
      ' WHERE (Cursada.CUTUCO = :COMI)'
      '   AND (Cursada.CUA_ANIO =  :CUAT)'
      '   AND (Cursada.CONDICION = '#39'CURSANDO'#39')'
      ' )'
      'ORDER BY Alumnos.APELLIDO,Alumnos.NOM_APE'
      ' '
      ' '
      ' '
      ' '
      ' ')
    Left = 120
    Top = 56
    ParamData = <
      item
        DataType = ftUnknown
        Name = 'COMI'
        ParamType = ptUnknown
      end
      item
        DataType = ftUnknown
        Name = 'CUAT'
        ParamType = ptUnknown
      end>
  end
  object PrintDialog1: TPrintDialog
    Left = 16
    Top = 56
  end
end
