unit lstdoccom;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Db, DBTables, StdCtrls, Buttons, Imprimir, GmTypes, GmPreview, Funciones;

type
  TFrmlstdoccom = class(TForm)
    GroupBox1: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    comision: TEdit;
    cuatrimestre: TEdit;
    Imprimir: TBitBtn;
    SqlCursada: TQuery;
    salir: TBitBtn;
    PrintDialog1: TPrintDialog;
    procedure FormActivate(Sender: TObject);
    procedure ImprimirClick(Sender: TObject);
    procedure salirClick(Sender: TObject);
    procedure comisionKeyPress(Sender: TObject; var Key: Char);
    procedure cuatrimestreKeyPress(Sender: TObject; var Key: Char);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Frmlstdoccom: TFrmlstdoccom;
  VCarrera : String[6]; //sirve para saber la carrera activa
  VUnidad : String[1]; //sirve para saber la unidad en la cual se corre el sistema
  VInstituto  : String[50]; //Pasa el nomnbre del instituto
  VCaracteristica : String[5]; //Pasa la caracteristica del colegio
  VCuatrimestreAnio : String[4]; //guarda el a�o cuatrimestre actual
  VNombreUsuario : String; //Trae el usuario que esta trabajando
  Plantilla : TMetaFile;
implementation

{$R *.DFM}

procedure TFrmlstdoccom.FormActivate(Sender: TObject);
begin
 //Borrar despues
 {VUnidad := 'C';
 VCarrera := 'ASC';
 VInstituto := 'Estudios Superiores de Buenos Aires A-781';
 VCaracteristica := 'A-781';
 VNombreUsuario := 'Rosa';
 //Hasta Aca }
 SqlCursada.DatabaseName := Vunidad + ':\New pailot\Archivos\' + Vcarrera;
 Comision.SetFocus;
 Cuatrimestre.text := Funciones.Cuatrimestre();
end;

procedure TFrmlstdoccom.ImprimirClick(Sender: TObject);
var
  largopagina:real;
begin
 Plantilla := TMetaFile.Create;
 Plantilla.LoadFromFile(VUnidad+':\New Pailot\Plantillas\Doc_Alum_x_Comi.emf');
 SqlCursada.Params.items[0].Value := StrtoInt(Comision.text);
 SqlCursada.Params.items[1].Value := Cuatrimestre.text;
 SqlCursada.Active:=True;
 If SqlCursada.RecordCount = 0 Then
   Begin
    MessageBox(FrmLstDocCom.Handle,Pchar(VNombreUsuario+', no hay ningun alumno con los datos ingresados.'),'Aviso',MB_OK+MB_APPLMODAL+MB_ICONINFORMATION);
    SqlCursada.Active := False;
   End
 Else
  If PrintDialog1.execute then
   Begin
    FormPreview:=tFormPreview.create(self);
    FormPreview.VistaPrevia1.Title := 'Documentaci�n por Comisi�n';
    largopagina:= 2.5;
    While not SqlCursada.eof do
     begin
      FormPreview.VistaPrevia1.BeginUpdate;
      FormPreview.VistaPrevia1.Canvas.StretchDraw(0,0,21,29.7,Plantilla,GmCentimeters);
      // **** INICIO DEL ENCABEZADO ***//
      FormPreview.VistaPrevia1.Canvas.Font.Name := 'Arial';
      FormPreview.VistaPrevia1.Canvas.Font.Size := 10;
      FormPreview.VistaPrevia1.Canvas.Font.Style := [FsBold];
      FormPreview.VistaPrevia1.Canvas.TextOut(17,1,DatetoStr(date),gmcentimeters);
      FormPreview.VistaPrevia1.Canvas.TextOutCenter(10,2.2,Comision.text,gmcentimeters);
      FormPreview.VistaPrevia1.Canvas.TextOutCenter(15,2.2,Vcarrera,gmcentimeters);
      // **** FIN DEL ENCABEZADO ***//
      // **** INICIO DEL DETALLE ***//
      FormPreview.VistaPrevia1.Canvas.Font.Name := 'Arial';
      FormPreview.VistaPrevia1.Canvas.Font.Size := 8;
      FormPreview.VistaPrevia1.Canvas.Font.Style := [];
      LargoPagina := 4.25;
      While (not SqlCursada.eof) and  (largopagina<=26) do
        begin
          If SqlCursada.Recno < 10 then
           FormPreview.VistaPrevia1.Canvas.TextOut(2.175,largopagina,IntToStr(SqlCursada.Recno),gmcentimeters)
          else
           FormPreview.VistaPrevia1.Canvas.TextOut(2,largopagina,IntToStr(SqlCursada.Recno),gmcentimeters);
          FormPreview.VistaPrevia1.Canvas.TextOut(3.5,largopagina,SqlCursada.FieldByName('APELLIDO').AsString + ' ' + SqlCursada.FieldByName('NOM_APE').AsString ,gmcentimeters);
          FormPreview.VistaPrevia1.Canvas.TextOut(11.5,largopagina,SqlCursada.FieldByName('DNI').AsString,gmcentimeters);
          FormPreview.VistaPrevia1.Canvas.TextOut(12.8,largopagina,SqlCursada.FieldByName('CA').AsString,gmcentimeters);
          If SqlCursada.FieldByName('CTT').AsString = '*' then
             FormPreview.VistaPrevia1.Canvas.TextOut(13.8,largopagina,DateToStr(SqlCursada.FieldByName('FECH_CTT').AsDateTime),gmcentimeters);
          FormPreview.VistaPrevia1.Canvas.TextOut(16.3,largopagina,SqlCursada.FieldByName('CD').AsString,gmcentimeters);
          FormPreview.VistaPrevia1.Canvas.TextOut(17.6,largopagina,SqlCursada.FieldByName('RESIDE').AsString,gmcentimeters);
          FormPreview.VistaPrevia1.Canvas.TextOut(19.2,largopagina,SqlCursada.FieldByName('CR').AsString,gmcentimeters);
          LargoPagina := LargoPagina + 0.82;
          SqlCursada.next;
        end;
        // fin del detalle
        FormPreview.VistaPrevia1.EndUpdate;
        if not SqlCursada.eof then
           FormPreview.VistaPrevia1.Newpage;
      end;
      FormPreview.VistaPrevia1.CurrentPage := 1;
     FormPreview.ShowModal;
     FormPreview.Free;
     SqlCursada.Active:=False;
  end;

end;

procedure TFrmlstdoccom.salirClick(Sender: TObject);
begin
  FrmLstDoccom.Close
end;

procedure TFrmlstdoccom.comisionKeyPress(Sender: TObject; var Key: Char);
begin
 If Key = #13 then
  Cuatrimestre.SetFocus ;
end;

procedure TFrmlstdoccom.cuatrimestreKeyPress(Sender: TObject;
  var Key: Char);
begin
if Key = #13 then
  Imprimir.SetFocus ;
end;

end.
