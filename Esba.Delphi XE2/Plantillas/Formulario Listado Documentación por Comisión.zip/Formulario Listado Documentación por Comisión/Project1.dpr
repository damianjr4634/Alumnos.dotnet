program Project1;

uses
  Forms,
  lstdoccom in 'lstdoccom.pas' {Frmlstdoccom},
//  Imprimir in '\\Esba-2\NEW PAILOT\New Pailot\PRG\Formulario Impresion\Imprimir.pas' {FormPreview},
//  Funciones in '\\esba-2\NEW PAILOT\New Pailot\PRG\ESBA\Funciones.pas';
  Imprimir in 'c:\New Pailot\PRG\Formulario Impresion\Imprimir.pas'{FormPreview},
  Funciones in 'c:\New Pailot\PRG\ESBA\Funciones.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TFrmlstdoccom, Frmlstdoccom);
  Application.Run;
end.
